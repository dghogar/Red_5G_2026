#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

#include <telit_sdk.h>
#include <telit_sdk_fota.h>
#include <tqcm.h>
#include <tqcm_fota.h>

static char *dev;
static char default_rmnet_dev[] = "/dev/cdc-wdm0";
static tqcm_context_t ctx;

int main(int argc, char **argv)
{
    int ret = EXIT_SUCCESS;
    tqcm_client_context_t ctx_fota;
    uint16_t sdk_error;
    fota_settings_t out;

    telit_set_log_level(LOG_INFO);

    if (argc == 1) {
        dev = default_rmnet_dev;
    } else {
        dev = argv[1];
    }

    ret = tqcm_init(dev, &ctx);
    if (ret != 0) {
        RLOGE("Failed tqcm initialization");
        ret = EXIT_FAILURE;
        goto end;
    }

    ret = tqcm_init_client_context(QMI_SVC_FOTA,
            &ctx,
            &ctx_fota,
            NULL);
    if (ret != 0) {
        RLOGE("Failed context opening");
        ret = EXIT_FAILURE;
        goto end;
    }

    RLOGD("Acquired client id %u", ctx_fota.client_id);

    ret = tqcm_fota_oem_ftp_get_settings_send(&ctx_fota,
            &out,
            &sdk_error,
            NULL,
            0);
    if (ret != 0) {
        RLOGE("send fail %d", ret);
        if (ret == EPROTO) {
            RLOGE("qmi protocol error 0x%04X", sdk_error);
        }
        ret = EXIT_FAILURE;
        goto context_disposal;
    } else {
        RLOGI("Success");
        RLOGI("Auto download firmware: %u", out.auto_download_firmware);
        RLOGI("Delta descriptor path: %u", out.auto_update_firmware);
        if (out.polling_time_available) {
            RLOGI("Polling time: %u", out.polling_time);
        }
        if (out.fw_auto_sdm_available) {
            RLOGI("FW auto sdm: %u", out.fw_auto_sdm);
        }
        if (out.auto_connect_available) {
            RLOGI("Auto connect: %u", out.auto_connect);
        }
        if (out.auto_reboot_available) {
            RLOGI("Auto reboot: %u", out.auto_reboot);
        }
    }

context_disposal:
    if (tqcm_deinit_client_context(&ctx, &ctx_fota) != 0) {
        RLOGE("Failed context disposal");
        ret = EXIT_FAILURE;
    }

    if (tqcm_deinit(&ctx) != 0) {
        RLOGE("Failed tqcm deinitialization");
        ret = EXIT_FAILURE;
        goto end;
    }

    /* Needed for valgrind complain about thread stack memory */
    sleep(1);

end:
    return ret;
}
